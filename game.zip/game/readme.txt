Copyright Notice:
-----------------
The files within this zip file are copyrighted by Lazy Foo' Productions (2004-2022)
and may not be redistributed without written permission.

This project is linked against:
CPP game implementation.


*nix:
SDL2
SDL2_image
SDL2_ttf

Music is downloaded from https://www.youtube.com/watch?v=S51ps-5vvIQ

The libraries are downloaded from LazyFoo.
//commands required to install SDL_image.h
sudo apt-cache search libsdl2-image
sudo apt-get install libsdl2-image-dev
//commands required to install SDL2
apt-cache search libsdl2
apt-get install libsdl2-dev

The rules are written in the power point presentation IIT DELHI MAP FOR GAME.pptx


