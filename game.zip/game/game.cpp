/*This source code copyrighted by Lazy Foo' Productions (2004-2022)
and may not be redistributed without written permission.*/

//Using SDL, SDL_image, standard IO, vectors, and strings
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <stdio.h>
#include <string>

//The dimensions of the level
const int LEVEL_WIDTH = 7680;
const int LEVEL_HEIGHT = 4608;

//Screen dimension constants
const int SCREEN_WIDTH = 1856;
const int SCREEN_HEIGHT = 992;

int i;
int j=1;
int sprite=0;
int score=0;
//Texture wrapper class
class LTexture
{
	public:
		//Initializes variables
		LTexture();

		//Deallocates memory
		~LTexture();

		//Loads image at specified path
		bool loadFromFile( std::string path );
		
		#if defined(SDL_TTF_MAJOR_VERSION)
		//Creates image from font string
		bool loadFromRenderedText( std::string textureText, SDL_Color textColor );
		#endif

		//Deallocates texture
		void free();

		//Set color modulation
		void setColor( Uint8 red, Uint8 green, Uint8 blue );

		//Set blending
		void setBlendMode( SDL_BlendMode blending );

		//Set alpha modulation
		void setAlpha( Uint8 alpha );
		
		//Renders texture at given point
		void render( int x, int y, SDL_Rect* clip = NULL, double angle = 0.0, SDL_Point* center = NULL, SDL_RendererFlip flip = SDL_FLIP_NONE );

		//Gets image dimensions
		int getWidth();
		int getHeight();

	private:
		//The actual hardware texture
		SDL_Texture* mTexture;
		

		//Image dimensions
		int mWidth;
		int mHeight;
};

//The dot that will move around on the screen
class Dot
{
    public:
		//The dimensions of the dot
		static const int DOT_WIDTH = 20;
		static const int DOT_HEIGHT = 20;

		//Maximum axis velocity of the dot
		static const int DOT_VEL = 10;

		//Initializes the variables
		Dot();

		//Takes key presses and adjusts the dot's velocity
		void handleEvent( SDL_Event& e );

		//Moves the dot
		void move(SDL_Rect walls[154] );

		//Shows the dot on the screen relative to the camera
		void render( int camX, int camY );

		//Position accessors
		int getPosX();
		int getPosY();
		
		int xxx=0;
		
		
		
		SDL_Rect mCollider;

    private:
		//The X and Y offsets of the dot
		int mPosX, mPosY;
		
		//Dot's collision box
		//SDL_Rect mCollider;

		//The velocity of the dot
		int mVelX, mVelY;
};
class Dog
{
    public:
		//The dimensions of the dog
		static const int DOG_WIDTH = 20;
		static const int DOG_HEIGHT = 20;

		//Maximum axis velocity of the dog
		static const int DOG_VEL = 10;

		//Initializes the variables
		Dog(int i, int j);

		//Takes key presses and adjusts the dog's velocity
		void handleEvent( SDL_Event& e );

		//Moves the dog
		void move(SDL_Rect walls[154] );

		//Shows the dog on the screen relative to the camera
		void render( int camX, int camY );

		//Position accessors
		int getPosX();
		int getPosY();

    private:
		//The X and Y offsets of the dog
		int gPosX, gPosY;
		
		//Dog's collision box
		SDL_Rect gCollider;

		//The velocity of the dog
		int gVelX, gVelY;
};

//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Box collision detector
bool checkCollision( SDL_Rect a, SDL_Rect b[154] );

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;

//The music that will be played
Mix_Music *gMusic = NULL;

//The sound effects that will be used
Mix_Chunk *gScratch = NULL;
Mix_Chunk *gHigh = NULL;
Mix_Chunk *gMedium = NULL;
Mix_Chunk *gLow = NULL;


//Scene textures

LTexture gpartyTexture;
LTexture gDot1Texture;
LTexture gDot2Texture;
LTexture gDot3Texture;
LTexture gDot4Texture;
LTexture gDot5Texture;
LTexture g0Texture;
LTexture g1Texture;
LTexture g2Texture;
LTexture g3Texture;
LTexture g4Texture;
LTexture g5Texture;
LTexture g6Texture;
LTexture g7Texture;
LTexture g8Texture;
LTexture g9Texture;
LTexture gtask1Texture;
LTexture gtask2Texture;
LTexture gtask3Texture;
LTexture gtask4Texture;
LTexture gtask5Texture;
LTexture gtask6Texture;
LTexture gtask7Texture;
LTexture gtask8Texture;
LTexture gtask9Texture;
LTexture gtask10Texture;
LTexture gtask11Texture;
LTexture gtask12Texture;
LTexture gtask13Texture;
LTexture gtask14Texture;
LTexture gtask15Texture;
LTexture gtask16Texture;
LTexture gtask17Texture;
LTexture gtask18Texture;
LTexture gtask19Texture;
LTexture gtask20Texture;
LTexture gtask21Texture;
LTexture gtask22Texture;
LTexture gtask23Texture;
LTexture gdog1Texture;
LTexture gdog2Texture;
LTexture gdog3Texture;
LTexture gdog4Texture;
LTexture gdog5Texture;
LTexture gdog6Texture;
LTexture gdog7Texture;
LTexture gdog8Texture;
LTexture gscoreaTexture;
LTexture gscorebTexture;
LTexture gBGTexture;

LTexture::LTexture()
{
	//Initialize
	mTexture = NULL;
	mWidth = 0;
	mHeight = 0;
}

LTexture::~LTexture()
{
	//Deallocate
	free();
}

bool LTexture::loadFromFile( std::string path )
{
	//Get rid of preexisting texture
	free();

	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Color key image
		SDL_SetColorKey( loadedSurface, SDL_TRUE, SDL_MapRGB( loadedSurface->format, 0, 0xFF, 0xFF ) );

		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}
		else
		{
			//Get image dimensions
			mWidth = loadedSurface->w;
			mHeight = loadedSurface->h;
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	//Return success
	mTexture = newTexture;
	return mTexture != NULL;
}

#if defined(SDL_TTF_MAJOR_VERSION)
bool LTexture::loadFromRenderedText( std::string textureText, SDL_Color textColor )
{
	//Get rid of preexisting texture
	free();

	//Render text surface
	SDL_Surface* textSurface = TTF_RenderText_Solid( gFont, textureText.c_str(), textColor );
	if( textSurface != NULL )
	{
		//Create texture from surface pixels
        mTexture = SDL_CreateTextureFromSurface( gRenderer, textSurface );
		if( mTexture == NULL )
		{
			printf( "Unable to create texture from rendered tex! SDL Error: %s\n", SDL_GetError() );
		}
		else
		{
			//Get image dimensions
			mWidth = textSurface->w;
			mHeight = textSurface->h;
		}

		//Get rid of old surface
		SDL_FreeSurface( textSurface );
	}
	else
	{
		printf( "Unable to render text surface! SDL_ttf Error: %s\n", TTF_GetError() );
	}

	
	//Return success
	return mTexture != NULL;
}
#endif

void LTexture::free()
{
	//Free texture if it exists
	if( mTexture != NULL )
	{
		SDL_DestroyTexture( mTexture );
		mTexture = NULL;
		mWidth = 0;
		mHeight = 0;
	}
}

void LTexture::setColor( Uint8 red, Uint8 green, Uint8 blue )
{
	//Modulate texture rgb
	SDL_SetTextureColorMod( mTexture, red, green, blue );
}

void LTexture::setBlendMode( SDL_BlendMode blending )
{
	//Set blending function
	SDL_SetTextureBlendMode( mTexture, blending );
}
		
void LTexture::setAlpha( Uint8 alpha )
{
	//Modulate texture alpha
	SDL_SetTextureAlphaMod( mTexture, alpha );
}

void LTexture::render( int x, int y, SDL_Rect* clip, double angle, SDL_Point* center, SDL_RendererFlip flip )
{
	//Set rendering space and render to screen
	SDL_Rect renderQuad = { x, y, mWidth, mHeight };

	//Set clip rendering dimensions
	if( clip != NULL )
	{
		renderQuad.w = clip->w;
		renderQuad.h = clip->h;
	}

	//Render to screen
	SDL_RenderCopyEx( gRenderer, mTexture, clip, &renderQuad, angle, center, flip );
}

int LTexture::getWidth()
{
	return mWidth;
}

int LTexture::getHeight()
{
	return mHeight;
}

Dot::Dot()
{
    //Initialize the offsets
    mPosX = 5024;
    mPosY = 608;
    
	//Set collision box dimension
	mCollider.w = DOT_WIDTH;
	mCollider.h = DOT_HEIGHT;
	
    //Initialize the velocity
    mVelX = 0;
    mVelY = 0;
}
Dog::Dog(int i,int j)
{
    //Initialize the offsets
    gPosX = i;
    gPosY = j;
    
	//Set collision box dimension
	gCollider.w = DOG_WIDTH;
	gCollider.h = DOG_HEIGHT;
	
    //Initialize the velocity
    gVelX = 0;
    gVelY = 0;
}

void Dot::handleEvent( SDL_Event& e )
{
    //If a key was pressed
	if( e.type == SDL_KEYDOWN  )
    {
    		
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {   case SDLK_g:if (i==0 && mPosX>=4704 && mPosX<=4768 && mPosY>=2432 && mPosY<=2463){}
        		 else if (i==1 && mPosX>=2816 && mPosX<=2848 && mPosY>=2784 && mPosY<=2848){}
        		 else if (i==2 && mPosX>=3648 && mPosX<=3712 && mPosY>=3616 && mPosY<=3648){}
        		 else if (i==3 && mPosX>=1856 && mPosX<=1888 && mPosY>=3040 && mPosY<=3104){}
        		 else if (i==4 && mPosX>=6144 && mPosX<=6176 && mPosY>=1632 && mPosY<=1696){}
        		 else if (i==5 && mPosX>=1184 && mPosX<=1248 && mPosY>=3936 && mPosY<=3968){}
        		 else if (i==6 && mPosX>=544 && mPosX<=576 && mPosY>=2720 && mPosY<=2784){}
        		 else if (i==7 && mPosX>=1856 && mPosX<=1888 && mPosY>=3232 && mPosY<=3296){}
        		 else if (i==8 && mPosX>=928 && mPosX<=960 && mPosY>=3488 && mPosY<=3552){}
        		 else if (i==9 && mPosX>=4320 && mPosX<=4352 && mPosY>=2528 && mPosY<=2592){}
        		 else if (i==10 && mPosX>=928 && mPosX<=960 && mPosY>=3008 && mPosY<=3072){}
        		 else if (i==11 && mPosX>=416 && mPosX<=480 && mPosY>=3808 && mPosY<=3872){}
        		 else if (i==12 && mPosX>=416 && mPosX<=480 && mPosY>=2944 && mPosY<=3008){}
        		 else if (i==13 && mPosX>=416 && mPosX<=480 && mPosY>=3488 && mPosY<=3552){}
        		 else if (i==14 && mPosX>=416 && mPosX<=480 && mPosY>=2560 && mPosY<=2624){}
        		 else if (i==15 && mPosX>=1024 && mPosX<=1088 && mPosY>=2464 && mPosY<=2528){}
        		 else if (i==16 && mPosX>=544 && mPosX<=608 && mPosY>=2368 && mPosY<=2432){}
        		 else if (i==17 && mPosX>=3360 && mPosX<=3392 && mPosY>=2784 && mPosY<=2848){}
        		 else if (i==18 && mPosX>=5856 && mPosX<=5920 && mPosY>=2688 && mPosY<=2720){}
        		 else if (i==19 && mPosX>=6080 && mPosX<=6112 && mPosY>=544 && mPosY<=608){}
        		 else if (i==20 && mPosX>=4608 && mPosX<=4672 && mPosY>=1952 && mPosY<=1984){} 
        		 else if (i==21 && mPosX>=1024 && mPosX<=1088 && mPosY>=2816 && mPosY<=2880){}
        		 else if (i==22 && mPosX>=1312 && mPosX<=1344 && mPosY>=3136 && mPosY<=3200){}break;
            case SDLK_l:if (mPosX>=1024 && mPosX<=7360 && mPosY>=4192 && mPosY<=4256) {Mix_PlayChannel( -1, gLow, 0 );}break;
	    case SDLK_r: if (mPosX>=1024 && mPosX<=7360 && mPosY>=4192 && mPosY<=4256) {Mix_PlayChannel( -1, gScratch, 0 );} break;
            case SDLK_d: if (mPosX>=7296 && mPosX<=7360 && mPosY>=1184 && mPosY<=4256) {Mix_PlayChannel( -1, gMedium, 0 );} break;
	     case SDLK_u:if (mPosX>=7296 && mPosX<=7360 && mPosY>=1184 && mPosY<=4256) {Mix_PlayChannel( -1, gHigh, 0 );} break;
            case SDLK_UP:Mix_PlayChannel( -1, gHigh, 0 );break;
            case SDLK_DOWN:Mix_PlayChannel( -1, gMedium, 0 ); break;
            case SDLK_LEFT:Mix_PlayChannel( -1, gLow, 0 ); break;
            case SDLK_RIGHT:Mix_PlayChannel( -1, gScratch, 0 ); break;}}

    //If a key was pressed
	if( e.type == SDL_KEYDOWN && e.key.repeat == 0 )
    {
    		
        //Adjust the velocity
        switch( e.key.keysym.sym )
        {   case SDLK_g:if (i==0 && mPosX>=4704 && mPosX<=4768 && mPosY>=2432 && mPosY<=2463){xxx=1;}
        		 else if (i==1 && mPosX>=2816 && mPosX<=2848 && mPosY>=2784 && mPosY<=2848){xxx=2;}
        		 else if (i==2 && mPosX>=3648 && mPosX<=3712 && mPosY>=3616 && mPosY<=3648){xxx=3;}
        		 else if (i==3 && mPosX>=1856 && mPosX<=1888 && mPosY>=3040 && mPosY<=3104){xxx=4;}
        		 else if (i==4 && mPosX>=6144 && mPosX<=6176 && mPosY>=1632 && mPosY<=1696){xxx=5;}
        		 else if (i==5 && mPosX>=1184 && mPosX<=1248 && mPosY>=3936 && mPosY<=3968){xxx=6;}
        		 else if (i==6 && mPosX>=544 && mPosX<=576 && mPosY>=2720 && mPosY<=2784){xxx=7;}
        		 else if (i==7 && mPosX>=1856 && mPosX<=1888 && mPosY>=3232 && mPosY<=3296){xxx=8;}
        		 else if (i==8 && mPosX>=928 && mPosX<=960 && mPosY>=3488 && mPosY<=3552){xxx=9;}
        		 else if (i==9 && mPosX>=4320 && mPosX<=4352 && mPosY>=2528 && mPosY<=2592){xxx=10;}
        		 else if (i==10 && mPosX>=928 && mPosX<=960 && mPosY>=3008 && mPosY<=3072){xxx=11;}
        		 else if (i==11 && mPosX>=416 && mPosX<=480 && mPosY>=3808 && mPosY<=3872){xxx=12;}
        		 else if (i==12 && mPosX>=416 && mPosX<=480 && mPosY>=2944 && mPosY<=3008){xxx=13;}
        		 else if (i==13 && mPosX>=416 && mPosX<=480 && mPosY>=3488 && mPosY<=3552){xxx=14;}
        		 else if (i==14 && mPosX>=416 && mPosX<=480 && mPosY>=2560 && mPosY<=2624){xxx=15;}
        		 else if (i==15 && mPosX>=1024 && mPosX<=1088 && mPosY>=2464 && mPosY<=2528){xxx=16;}
        		 else if (i==16 && mPosX>=544 && mPosX<=608 && mPosY>=2368 && mPosY<=2432){xxx=17;}
        		 else if (i==17 && mPosX>=3360 && mPosX<=3392 && mPosY>=2784 && mPosY<=2848){xxx=18;}
        		 else if (i==18 && mPosX>=5856 && mPosX<=5920 && mPosY>=2688 && mPosY<=2720){xxx=19;}
        		 else if (i==19 && mPosX>=6080 && mPosX<=6112 && mPosY>=544 && mPosY<=608){xxx=20;}
        		 else if (i==20 && mPosX>=4608 && mPosX<=4672 && mPosY>=1952 && mPosY<=1984){xxx=21;} 
        		 else if (i==21 && mPosX>=1024 && mPosX<=1088 && mPosY>=2816 && mPosY<=2880){xxx=22;}
        		 else if (i==22 && mPosX>=1312 && mPosX<=1344 && mPosY>=3136 && mPosY<=3200){xxx=23;}break;
            case SDLK_l:sprite=1;  if (mPosX>=1024 && mPosX<=7360 && mPosY>=4192 && mPosY<=4256) {mVelX-=5*DOT_VEL;} break;
	    case SDLK_r: sprite=2; if (mPosX>=1024 && mPosX<=7360 && mPosY>=4192 && mPosY<=4256) {mVelX+=5*DOT_VEL;} break;
            case SDLK_d:sprite=4;  if (mPosX>=7296 && mPosX<=7360 && mPosY>=1184 && mPosY<=4256)  {mVelY+=5*DOT_VEL;} break;
	     case SDLK_u:sprite=3;  if (mPosX>=7296 && mPosX<=7360 && mPosY>=1184 && mPosY<=4256) {mVelY-=5*DOT_VEL;} break;
            case SDLK_UP:sprite=3; mVelY -= DOT_VEL; break;
            case SDLK_DOWN:sprite=4;mVelY += DOT_VEL; break;
            case SDLK_LEFT: sprite=1;mVelX -= DOT_VEL; break;
            case SDLK_RIGHT:sprite=2;mVelX += DOT_VEL; break;
            case SDLK_m:
							//If there is no music playing
							if( Mix_PlayingMusic() == 0 )
							{
								//Play the music
								Mix_PlayMusic( gMusic, -1 );
							}
							//If music is being played
							else
							{
								//If the music is paused
								if( Mix_PausedMusic() == 1 )
								{
									//Resume the music
									Mix_ResumeMusic();
								}
								//If the music is playing
								else
								{
									//Pause the music
									Mix_PauseMusic();
								}
							}
							break;
        }
    }
    //If a key was released
    else if( e.type == SDL_KEYUP && e.key.repeat == 0 )
    {	
        	
        //Adjust the velocity
        switch( e.key.keysym.sym )
  {
  	    case SDLK_l: sprite=0; mVelX =0; break;
  	    case SDLK_r: sprite=0; mVelX =0; break;
  	    case SDLK_u:sprite=0;  mVelY =0; break;
  	    case SDLK_d:sprite=0;  mVelY =0; break;
            case SDLK_UP: sprite=0; mVelY += DOT_VEL; break;
            case SDLK_DOWN: sprite=0; mVelY -= DOT_VEL; break;
            case SDLK_LEFT:sprite=0; mVelX += DOT_VEL; break;
            case SDLK_RIGHT:sprite=0;  mVelX -= DOT_VEL; break;
        }
    }
}
void Dog::handleEvent( SDL_Event& e )
{
        //Adjust the velocity
		gVelY = 2-(rand()%4); 
               gVelX = 2-(rand()%4);    
} 
void Dot::move( SDL_Rect walls[154] )
{

    //Move the dot left or right
    mPosX += mVelX;
	mCollider.x = mPosX;

    //If the dot collided or went too far to the left or right
    if( ( mPosX < 0 ) || ( mPosX + DOT_WIDTH > LEVEL_WIDTH ) || checkCollision( mCollider, walls ) )
    {
        //Move back
        mPosX -= mVelX;
		mCollider.x = mPosX;
    }

    //Move the dot up or down
    mPosY += mVelY;
	mCollider.y = mPosY;

    //If the dot collided or went too far up or down
    if( ( mPosY < 0 ) || ( mPosY + DOT_HEIGHT > LEVEL_HEIGHT ) || checkCollision( mCollider, walls ) )
    {
        //Move back
        mPosY -= mVelY;
		mCollider.y = mPosY;
    }

}
void Dog::move( SDL_Rect walls[154] )
{
    //Move the dog left or right
    gPosX += gVelX;
	gCollider.x = gPosX;

    //If the dog collided or went too far to the left or right
    if( ( gPosX < 0 ) || ( gPosX + DOG_WIDTH > LEVEL_WIDTH ) || checkCollision( gCollider, walls ) )
    {
        //Move back
        gPosX -= gVelX;
		gCollider.x = gPosX;
    }

    //Move the dog up or down
    gPosY += gVelY;
	gCollider.y = gPosY;

    //If the dog collided or went too far up or down
    if( ( gPosY < 0 ) || ( gPosY + DOG_HEIGHT > LEVEL_HEIGHT ) || checkCollision( gCollider, walls ) )
    {
        //Move back
        gPosY -= gVelY;
		gCollider.y = gPosY;
    }

}

void Dot::render( int camX, int camY )
{
    //Show the dot relative to the camera
	if (sprite==1){gDot2Texture.render( mPosX - camX, mPosY - camY );}
	else if (sprite==2){gDot3Texture.render( mPosX - camX, mPosY - camY );}
	else if (sprite==3){gDot4Texture.render( mPosX - camX, mPosY - camY );}
	else if (sprite==4){gDot5Texture.render( mPosX - camX, mPosY - camY );}
	else {gDot1Texture.render( mPosX - camX, mPosY - camY );}
	if(score==0){gDot2Texture.render(  mPosX, mPosY );}
}
void Dog::render( int camX, int camY )
{
    //Show the dog relative to the camera
	gdog1Texture.render( gPosX -camX, gPosY-camY );
	gdog2Texture.render( gPosX -camX, gPosY-camY );
	gdog3Texture.render( gPosX -camX, gPosY-camY );
	gdog4Texture.render( gPosX -camX, gPosY-camY );
	gdog5Texture.render( gPosX -camX, gPosY-camY );
	gdog6Texture.render( gPosX -camX, gPosY-camY );
	gdog7Texture.render( gPosX -camX, gPosY-camY );
	gdog8Texture.render( gPosX -camX, gPosY-camY );
	
}

int Dot::getPosX()
{
	return mPosX;
}

int Dot::getPosY()
{
	return mPosY;
}

int Dog::getPosX()
{
	return gPosX;
}

int Dog::getPosY()
{
	return gPosY;
}


bool init()
{
	//Initialization flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create vsynced renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
								 //Initialize SDL_mixer
				if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
				{
					printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success flag
	bool success = true;

	//Load dot texture
	if( !gpartyTexture.loadFromFile( "party.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gDot1Texture.loadFromFile( "still.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gDot2Texture.loadFromFile( "left.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gDot3Texture.loadFromFile( "right.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gDot4Texture.loadFromFile( "up.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gDot5Texture.loadFromFile( "down.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g0Texture.loadFromFile( "0.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g1Texture.loadFromFile( "1.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g2Texture.loadFromFile( "2.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g3Texture.loadFromFile( "3.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g4Texture.loadFromFile( "4.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g5Texture.loadFromFile( "5.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g6Texture.loadFromFile( "6.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g7Texture.loadFromFile( "7.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g8Texture.loadFromFile( "8.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !g9Texture.loadFromFile( "9.jpg" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask1Texture.loadFromFile( "task1.png" ) )
	{
		printf( "Failed to load task1 texture!\n" );
		success = false;
	}
	if( !gtask2Texture.loadFromFile( "task2.png" ) )
	{
		printf( "Failed to load task2 texture!\n" );
		success = false;
	}	
	if( !gtask3Texture.loadFromFile( "task3.png" ) )
	{
		printf( "Failed to load task3 texture!\n" );
		success = false;
	}
	if( !gtask4Texture.loadFromFile( "task4.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask5Texture.loadFromFile( "task5.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask6Texture.loadFromFile( "task6.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask7Texture.loadFromFile( "task7.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask8Texture.loadFromFile( "task8.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}	
	if( !gtask9Texture.loadFromFile( "task9.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask10Texture.loadFromFile( "task10.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask11Texture.loadFromFile( "task11.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask12Texture.loadFromFile( "task12.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask13Texture.loadFromFile( "task13.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask14Texture.loadFromFile( "task14.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}	
	if( !gtask15Texture.loadFromFile( "task15.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask16Texture.loadFromFile( "task16.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask17Texture.loadFromFile( "task17.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask18Texture.loadFromFile( "task18.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask19Texture.loadFromFile( "task19.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask20Texture.loadFromFile( "task20.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}	
	if( !gtask21Texture.loadFromFile( "task21.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask22Texture.loadFromFile( "task22.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gtask23Texture.loadFromFile( "task23.png" ) )
	{
		printf( "Failed to load dot texture!\n" );
		success = false;
	}
	if( !gdog2Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}	
	if( !gdog3Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}	
	if( !gdog4Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}	
	if( !gdog5Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}	
	if( !gdog6Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}	
	if( !gdog7Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}	
	if( !gdog8Texture.loadFromFile( "dog.jpg" ) )
	{
		printf( "Failed to load dog texture!\n" );
		success = false;
	}
	if( !gscoreaTexture.loadFromFile( "abig.png" ) )
	{
		printf( "Failed to load scorea texture!\n" );
		success = false;
	}
	if( !gscorebTexture.loadFromFile( "bbig.png" ) )
	{
		printf( "Failed to load scoreb texture!\n" );
		success = false;
	}
		//Load background texture
	if( !gBGTexture.loadFromFile( "iitd map.png" ) )
	{
		printf( "Failed to load background texture!\n" );
		success = false;
	}
	//Load music
	gMusic = Mix_LoadMUS( "sound.wav" );
	if( gMusic == NULL )
	{
		printf( "Failed to load beat music! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}
	
	//Load sound effects
	gScratch = Mix_LoadWAV( "scratch.wav" );
	if( gScratch == NULL )
	{
		printf( "Failed to load scratch sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}
	
	gHigh = Mix_LoadWAV( "high.wav" );
	if( gHigh == NULL )
	{
		printf( "Failed to load high sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}

	gMedium = Mix_LoadWAV( "medium.wav" );
	if( gMedium == NULL )
	{
		printf( "Failed to load medium sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}

	gLow = Mix_LoadWAV( "low.wav" );
	if( gLow == NULL )
	{
		printf( "Failed to load low sound effect! SDL_mixer Error: %s\n", Mix_GetError() );
		success = false;
	}

	return success;
}

void close()
{
	//Free loaded images
	gpartyTexture.free();gDot1Texture.free();gDot2Texture.free();gDot3Texture.free();gDot4Texture.free();gDot5Texture.free();g0Texture.free();g1Texture.free();g2Texture.free();g3Texture.free();g4Texture.free();g5Texture.free();g6Texture.free();g7Texture.free();g8Texture.free();g9Texture.free();
	gtask1Texture.free();
	gtask2Texture.free();
	gtask3Texture.free();
	gtask4Texture.free();
	gtask5Texture.free();
	gtask6Texture.free();
	gtask7Texture.free();
	gtask8Texture.free();
	gtask9Texture.free();
	gtask10Texture.free();
	gtask11Texture.free();
	gtask12Texture.free();
	gtask13Texture.free();
	gtask14Texture.free();
	gtask15Texture.free();
	gtask16Texture.free();
	gtask17Texture.free();
	gtask18Texture.free();
	gtask19Texture.free();
	gtask20Texture.free();
	gtask21Texture.free();
	gtask22Texture.free();
	gtask23Texture.free();
	gscoreaTexture.free();
	gscorebTexture.free();	
	gdog1Texture.free();	
	gdog2Texture.free();	
	gdog3Texture.free();	
	gdog4Texture.free();	
	gdog5Texture.free();	
	gdog6Texture.free();	
	gdog7Texture.free();	
	gdog8Texture.free();
	gBGTexture.free();


	//Free the sound effects
	Mix_FreeChunk( gScratch );
	Mix_FreeChunk( gHigh );
	Mix_FreeChunk( gMedium );
	Mix_FreeChunk( gLow );
	gScratch = NULL;
	gHigh = NULL;
	gMedium = NULL;
	gLow = NULL;
	
	//Free the music
	Mix_FreeMusic( gMusic );
	gMusic = NULL;

	//Destroy window	
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
	Mix_Quit();
}



bool checkCollision( SDL_Rect a, SDL_Rect b[154] )
{
    //The sides of the rectangles
    int i=0;
    bool boo=false;
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;
    //Calculate the sides of rect A
    leftA = a.x;
    rightA = a.x + a.w;
    topA = a.y;
    bottomA = a.y + a.h;
    while(i<154 && boo==false){


    //Calculate the sides of rect B
    leftB = b[i].x;
    rightB = b[i].x + b[i].w;
    topB = b[i].y;
    bottomB = b[i].y + b[i].h;

    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        boo=false;
    }

    else if( topA >= bottomB )
    {
        boo=false;
    }

    else if( rightA <= leftB )
    {
        boo=false;
    }

    else if( leftA >= rightB )
    {
        boo=false;
    }
    else { boo=true;} 
    i++;
    }
    //If none of the sides from A are outside B
    return boo;
}
bool dogCollision( SDL_Rect a, Dog b[8] )
{
    //The sides of the rectangles
    int i=0;
    bool boo=false;
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;
    //Calculate the sides of rect A
    leftA = a.x;
    rightA = a.x + a.w;
    topA = a.y;
    bottomA = a.y + a.h;
    while(i<154 && boo==false){


    //Calculate the sides of rect B
    leftB = b[i].getPosX();
    rightB = b[i].getPosX() + 32;
    topB = b[i].getPosY();
    bottomB = b[i].getPosY() + 32;

    //If any of the sides from A are outside of B
    if( bottomA <= topB )
    {
        boo=false;
    }

    else if( topA >= bottomB )
    {
        boo=false;
    }

    else if( rightA <= leftB )
    {
        boo=false;
    }

    else if( leftA >= rightB )
    {
        boo=false;
    }
    else { boo=true;} 
    i++;
    }
    //If none of the sides from A are outside B
    return boo;
}




int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
		//Load media
		if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{	
			
			//Main loop flag
			bool quit = false;

			//Event handler
			SDL_Event e;

			//The dot that will be moving around on the screen
			Dot dot;
			//The dog that will be moving around on the screen
			Dog dog1(6176,2944);
			Dog dog2(416,3488);
			Dog dog3(1888,2208);
			Dog dog4(4224,2592);
			Dog dog5(6240,1408);
			Dog dog6(3008,3456);
			Dog dog7(960,2464);
			Dog dog8(2752,2592);

			//The camera area
			SDL_Rect camera = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };

			//While application is running
			while( !quit )
			{
				//Handle events on queue
				while( SDL_PollEvent( &e ) != 0 )
				{	
					//User requests quit
					if( e.type == SDL_QUIT )
					{
						quit = true;
					}
					
					//Handle input for the dot
					dot.handleEvent( e );
					dog1.handleEvent( e );
					dog2.handleEvent( e );
					dog3.handleEvent( e );
					dog4.handleEvent( e );
					dog5.handleEvent( e );
					dog6.handleEvent( e );
					dog7.handleEvent( e );
					dog8.handleEvent( e );
					Dog dogs[8]={dog1,dog2,dog3,dog4,dog5,dog6,dog7,dog8};
					if ( dogCollision(dot.mCollider,dogs)==true){
						if (score!=0) {score=score-5;}}
				}
			//Set the wall
SDL_Rect wall1;SDL_Rect wall2;SDL_Rect wall3;SDL_Rect wall4;SDL_Rect wall5;SDL_Rect wall6;SDL_Rect wall7;SDL_Rect wall8;SDL_Rect wall9;SDL_Rect wall10;SDL_Rect wall11;SDL_Rect wall12;SDL_Rect wall13;SDL_Rect wall14;SDL_Rect wall15;SDL_Rect wall16;SDL_Rect wall17;SDL_Rect wall18;SDL_Rect wall19;SDL_Rect wall20;SDL_Rect wall21;SDL_Rect wall22;SDL_Rect wall23;SDL_Rect wall24;SDL_Rect wall25;SDL_Rect wall26;SDL_Rect wall27;SDL_Rect wall28;SDL_Rect wall29;SDL_Rect wall30;SDL_Rect wall31;SDL_Rect wall32;SDL_Rect wall33;SDL_Rect wall34;SDL_Rect wall35;SDL_Rect wall36;SDL_Rect wall37;SDL_Rect wall38;SDL_Rect wall39;SDL_Rect wall40;SDL_Rect wall41;SDL_Rect wall42;SDL_Rect wall43;SDL_Rect wall44;SDL_Rect wall45;SDL_Rect wall46;SDL_Rect wall47;SDL_Rect wall48;SDL_Rect wall49;SDL_Rect wall50;SDL_Rect wall51;SDL_Rect wall52;SDL_Rect wall53;SDL_Rect wall54;SDL_Rect wall55;SDL_Rect wall56;SDL_Rect wall57;SDL_Rect wall58;SDL_Rect wall59;SDL_Rect wall60;SDL_Rect wall61;SDL_Rect wall62;SDL_Rect wall63;SDL_Rect wall64;SDL_Rect wall65;SDL_Rect wall66;SDL_Rect wall67;SDL_Rect wall68;SDL_Rect wall69;SDL_Rect wall70;SDL_Rect wall71;SDL_Rect wall72;SDL_Rect wall73;SDL_Rect wall74;SDL_Rect wall75;SDL_Rect wall76;SDL_Rect wall77;SDL_Rect wall78;SDL_Rect wall79;SDL_Rect wall80;SDL_Rect wall81;SDL_Rect wall82;SDL_Rect wall83;SDL_Rect wall84;SDL_Rect wall85;SDL_Rect wall86;SDL_Rect wall87;SDL_Rect wall88;SDL_Rect wall89;SDL_Rect wall90;
SDL_Rect wall91;SDL_Rect wall92;SDL_Rect wall93;SDL_Rect wall94;SDL_Rect wall95;SDL_Rect wall96;SDL_Rect wall97;SDL_Rect wall98;SDL_Rect wall99;SDL_Rect wall100;SDL_Rect wall101;SDL_Rect wall102;SDL_Rect wall103;SDL_Rect wall104;SDL_Rect wall105;SDL_Rect wall106;SDL_Rect wall107;SDL_Rect wall108;SDL_Rect wall109;SDL_Rect wall110;SDL_Rect wall111;SDL_Rect wall112;SDL_Rect wall113;SDL_Rect wall114;SDL_Rect wall115;SDL_Rect wall116;SDL_Rect wall117;SDL_Rect wall118;SDL_Rect wall119;SDL_Rect wall120;SDL_Rect wall121;SDL_Rect wall122;SDL_Rect wall123;SDL_Rect wall124;SDL_Rect wall125;SDL_Rect wall126;SDL_Rect wall127;SDL_Rect wall128;SDL_Rect wall129;SDL_Rect wall130;SDL_Rect wall131;SDL_Rect wall132;SDL_Rect wall133;SDL_Rect wall134;SDL_Rect wall135;SDL_Rect wall136;SDL_Rect wall137;SDL_Rect wall138;SDL_Rect wall139;SDL_Rect wall140;SDL_Rect wall141;SDL_Rect wall142;SDL_Rect wall143;SDL_Rect wall144;SDL_Rect wall145;SDL_Rect wall146;SDL_Rect wall147;SDL_Rect wall148;SDL_Rect wall149;SDL_Rect wall150;SDL_Rect wall151;SDL_Rect wall152; SDL_Rect wall153; SDL_Rect wall154;
wall1.x=0;wall1.y=0;wall1.w=4256;wall1.h=2112;
wall2.x=4256;wall2.y=0;wall2.w=768;wall2.h=1120;
wall3.x=5024;wall3.y=0;wall3.w=2656;wall3.h=352;
wall4.x=5024;wall4.y=352;wall4.w=672;wall4.h=224;
wall5.x=5088;wall5.y=576;wall5.w=608;wall5.h=544;
wall6.x=6080;wall6.y=608;wall6.w=96;wall6.h=512;
wall7.x=6080;wall7.y=352;wall7.w=1600;wall7.h=192;
wall8.x=6240;wall8.y=544;wall8.w=1440;wall8.h=64;
wall9.x=6432;wall9.y=608;wall9.w=32;wall9.h=512;
wall10.x=6912;wall10.y=608;wall10.w=448;wall10.h=512;
wall11.x=7360;wall11.y=608;wall11.w=320;wall11.h=4000;
wall12.x=6240;wall12.y=1760;wall12.w=1056;wall12.h=2432;
wall13.x=5696;wall13.y=1088;wall13.w=160;wall13.h=32;
wall14.x=5920;wall14.y=1088;wall14.w=192;wall14.h=32;
wall15.x=6624;wall15.y=896;wall15.w=32;wall15.h=96;
wall16.x=6624;wall16.y=736;wall16.w=32;wall16.h=96;
wall17.x=6272;wall17.y=608;wall17.w=352;wall17.h=512;
wall18.x=6240;wall18.y=1056;wall18.w=32;wall18.h=64;
wall19.x=5696;wall19.y=352;wall19.w=384;wall19.h=32;
wall20.x=6624;wall20.y=544;wall20.w=32;wall20.h=128;
wall21.x=6240;wall21.y=896;wall21.w=32;wall21.h=96;
wall22.x=6240;wall22.y=736;wall22.w=32;wall22.h=96;
wall23.x=6240;wall23.y=544;wall23.w=32;wall23.h=128;
wall24.x=6624;wall24.y=1056;wall24.w=32;wall24.h=64;
wall25.x=5696;wall25.y=384;wall25.w=384;wall25.h=704;
wall26.x=6752;wall26.y=608;wall26.w=192;wall26.h=512;
wall27.x=6720;wall27.y=1056;wall27.w=32;wall27.h=64;
wall28.x=6720;wall28.y=896;wall28.w=32;wall28.h=96;
wall29.x=6720;wall29.y=736;wall29.w=32;wall29.h=96;
wall30.x=576;wall30.y=4256;wall30.w=6816;wall30.h=352;
wall31.x=544;wall31.y=4160;wall31.w=480;wall31.h=128;
wall32.x=544;wall32.y=4352;wall32.w=32;wall32.h=256;
wall33.x=0;wall33.y=4096;wall33.w=64;wall33.h=512;
wall34.x=64;wall34.y=4160;wall34.w=416;wall34.h=448;
wall35.x=480;wall35.y=4448;wall35.w=64;wall35.h=160;
wall36.x=0;wall36.y=2112;wall36.w=416;wall36.h=1984;
wall37.x=416;wall37.y=2112;wall37.w=64;wall37.h=448;
wall38.x=416;wall38.y=2624;wall38.w=64;wall38.h=320;
wall39.x=416;wall39.y=3008;wall39.w=64;wall39.h=480;
wall40.x=416;wall40.y=3552;wall40.w=64;wall40.h=256;
wall41.x=416;wall41.y=3872;wall41.w=64;wall41.h=224;
wall42.x=544;wall42.y=3456;wall42.w=416;wall42.h=32;
wall43.x=544;wall43.y=3488;wall43.w=384;wall43.h=64;
wall44.x=544;wall44.y=3552;wall44.w=416;wall44.h=544;
wall45.x=5088;wall45.y=1184;wall45.w=1056;wall45.h=3008;
wall46.x=6144;wall46.y=1184;wall46.w=32;wall46.h=64;
wall47.x=6144;wall47.y=1312;wall47.w=32;wall47.h=96;
wall48.x=6144;wall48.y=1472;wall48.w=32;wall48.h=160;
wall49.x=6144;wall49.y=1696;wall49.w=32;wall49.h=2496;
wall50.x=1440;wall50.y=3488;wall50.w=2176;wall50.h=704;
wall51.x=3648;wall51.y=3648;wall51.w=64;wall51.h=544;
wall52.x=3712;wall52.y=3488;wall52.w=1408;wall52.h=704;
wall53.x=1440;wall53.y=3456;wall53.w=1568;wall53.h=32;
wall54.x=3072;wall54.y=3456;wall54.w=352;wall54.h=32;
wall55.x=3488;wall55.y=3456;wall55.w=160;wall55.h=32;
wall56.x=3712;wall56.y=3456;wall56.w=448;wall56.h=32;
wall57.x=4224;wall57.y=3456;wall57.w=896;wall57.h=32;
wall58.x=1024;wall58.y=3456;wall58.w=448;wall58.h=192;
wall59.x=1056;wall59.y=3648;wall59.w=416;wall59.h=64;
wall60.x=1024;wall60.y=3712;wall60.w=448;wall60.h=64;
wall61.x=1248;wall61.y=3776;wall61.w=192;wall61.h=128;
wall62.x=1024;wall62.y=3840;wall62.w=128;wall62.h=256;
wall63.x=1152;wall63.y=3936;wall63.w=32;wall63.h=224;
wall64.x=1120;wall64.y=4096;wall64.w=352;wall64.h=64;
wall65.x=1184;wall65.y=3968;wall65.w=288;wall65.h=192;
wall66.x=1088;wall66.y=4096;wall66.w=32;wall66.h=96;
wall67.x=1088;wall67.y=4160;wall67.w=384;wall67.h=32;
wall68.x=4320;wall68.y=1184;wall68.w=288;wall68.h=320;
wall69.x=4320;wall69.y=1568;wall69.w=288;wall69.h=320;
wall70.x=4672;wall70.y=1184;wall70.w=352;wall70.h=320;
wall71.x=4672;wall71.y=1568;wall71.w=352;wall71.h=320;
wall72.x=4608;wall72.y=1216;wall72.w=64;wall72.h=640;
wall73.x=4352;wall73.y=1504;wall73.w=640;wall73.h=64;
wall74.x=4320;wall74.y=1984;wall74.w=704;wall74.h=384;
wall75.x=4320;wall75.y=1952;wall75.w=288;wall75.h=32;
wall76.x=4672;wall76.y=1952;wall76.w=352;wall76.h=32;
wall77.x=4352;wall77.y=2464;wall77.w=672;wall77.h=928;
wall78.x=4320;wall78.y=2848;wall78.w=32;wall78.h=544;
wall79.x=4320;wall79.y=2592;wall79.w=32;wall79.h=192;
wall80.x=4320;wall80.y=2432;wall80.w=32;wall80.h=96;
wall81.x=4320;wall81.y=2432;wall81.w=384;wall81.h=32;
wall82.x=4768;wall82.y=2432;wall82.w=256;wall82.h=32;
wall83.x=544;wall83.y=2944;wall83.w=384;wall83.h=448;
wall84.x=928;wall84.y=3296;wall84.w=32;wall84.h=96;
wall85.x=928;wall85.y=2944;wall85.w=32;wall85.h=64;
wall86.x=928;wall86.y=3072;wall86.w=32;wall86.h=160;
wall87.x=544;wall87.y=2624;wall87.w=416;wall87.h=96;
wall88.x=576;wall88.y=2720;wall88.w=384;wall88.h=64;
wall89.x=544;wall89.y=2784;wall89.w=416;wall89.h=96;
wall90.x=544;wall90.y=2080;wall90.w=1312;wall90.h=288;
wall91.x=608;wall91.y=2368;wall91.w=1248;wall91.h=64;
wall92.x=544;wall92.y=2432;wall92.w=416;wall92.h=128;
wall93.x=960;wall93.y=2432;wall93.w=896;wall93.h=32;
wall94.x=1088;wall94.y=2464;wall94.w=768;wall94.h=64;
wall95.x=1024;wall95.y=2528;wall95.w=832;wall95.h=128;
wall96.x=1856;wall96.y=2048;wall96.w=32;wall96.h=160;
wall97.x=1856;wall97.y=2272;wall97.w=32;wall97.h=96;
wall98.x=1856;wall98.y=2432;wall98.w=32;wall98.h=96;
wall99.x=1856;wall99.y=2592;wall99.w=32;wall99.h=64;
wall100.x=1888;wall100.y=2048;wall100.w=64;wall100.h=96;
wall101.x=1952;wall101.y=2048;wall101.w=32;wall101.h=160;
wall102.x=1952;wall102.y=2272;wall102.w=32;wall102.h=96;
wall103.x=1952;wall103.y=2432;wall103.w=32;wall103.h=96;
wall104.x=1952;wall104.y=2592;wall104.w=32;wall104.h=64;
wall105.x=1984;wall105.y=2048;wall105.w=288;wall105.h=608;
wall106.x=2272;wall106.y=2048;wall106.w=64;wall106.h=544;
wall107.x=2336;wall107.y=2048;wall107.w=160;wall107.h=608;
wall108.x=2496;wall108.y=2048;wall108.w=256;wall108.h=736;
wall109.x=2752;wall109.y=2048;wall109.w=1504;wall109.h=544;
wall110.x=3456;wall110.y=2592;wall110.w=768;wall110.h=64;
wall111.x=3456;wall111.y=2656;wall111.w=800;wall111.h=224;
wall112.x=3456;wall112.y=2880;wall112.w=416;wall112.h=512;
wall113.x=3936;wall113.y=2944;wall113.w=128;wall113.h=448;
wall114.x=4064;wall114.y=2944;wall114.w=64;wall114.h=416;
wall115.x=4128;wall115.y=2944;wall115.w=128;wall115.h=448;
wall116.x=2816;wall116.y=3040;wall116.w=640;wall116.h=320;
wall117.x=2816;wall117.y=3360;wall117.w=64;wall117.h=32;
wall118.x=2944;wall118.y=3360;wall118.w=128;wall118.h=32;
wall119.x=3136;wall119.y=3360;wall119.w=736;wall119.h=32;
wall120.x=2496;wall120.y=2848;wall120.w=256;wall120.h=128;
wall121.x=2816;wall121.y=2656;wall121.w=576;wall121.h=128;
wall122.x=2848;wall122.y=2784;wall122.w=512;wall122.h=64;
wall123.x=2816;wall123.y=2848;wall123.w=576;wall123.h=128;
wall124.x=1952;wall124.y=3040;wall124.w=800;wall124.h=352;
wall125.x=1952;wall125.y=2720;wall125.w=448;wall125.h=320;
wall126.x=2400;wall126.y=2720;wall126.w=32;wall126.h=64;
wall127.x=2400;wall127.y=2848;wall127.w=32;wall127.h=192;
wall128.x=1024;wall128.y=2720;wall128.w=864;wall128.h=96;
wall129.x=1088;wall129.y=2816;wall129.w=800;wall129.h=64;
wall130.x=1024;wall130.y=2880;wall130.w=864;wall130.h=160;
wall131.x=1024;wall131.y=3040;wall131.w=832;wall131.h=64;
wall132.x=1056;wall132.y=3104;wall132.w=832;wall132.h=32;
wall133.x=1344;wall133.y=3136;wall133.w=544;wall133.h=64;
wall134.x=1024;wall134.y=3200;wall134.w=832;wall134.h=192;
wall135.x=1856;wall135.y=3104;wall135.w=32;wall135.h=128;
wall136.x=1856;wall136.y=3296;wall136.w=32;wall136.h=96;
wall137.x=6240;wall137.y=1184;wall137.w=416;wall137.h=64;
wall138.x=6272;wall138.y=1248;wall138.w=352;wall138.h=64;
wall139.x=6240;wall139.y=1312;wall139.w=416;wall139.h=96;
wall140.x=6272;wall140.y=1408;wall140.w=352;wall140.h=64;
wall141.x=6240;wall141.y=1472;wall141.w=416;wall141.h=96;
wall142.x=6272;wall142.y=1568;wall142.w=352;wall142.h=64;
wall143.x=6240;wall143.y=1632;wall143.w=416;wall143.h=64;
wall144.x=6720;wall144.y=1184;wall144.w=576;wall144.h=64;
wall145.x=6752;wall145.y=576;wall145.w=544;wall145.h=64;
wall146.x=6720;wall146.y=1312;wall146.w=576;wall146.h=32;
wall147.x=6720;wall147.y=1344;wall147.w=544;wall147.h=64;
wall148.x=6752;wall148.y=1408;wall148.w=544;wall148.h=64;
wall149.x=6720;wall149.y=1472;wall149.w=576;wall149.h=96;
wall150.x=6752;wall150.y=1568;wall150.w=544;wall150.h=64;
wall151.x=6720;wall151.y=1632;wall151.w=576;wall151.h=64;
wall152.x=6720;wall152.y=608;wall152.w=32;wall152.h=64;
wall153.x=3616;wall153.y=3456;wall153.w=32;wall153.h=736;
wall154.x=6752;wall154.y=1248;wall154.w=544;wall154.h=64;
			//set the walls
			SDL_Rect walls[154]={wall1,wall2,wall3,wall4,wall5,wall6,wall7,wall8,wall9,wall10,wall11,wall12,wall13,wall14,wall15,wall16,wall17,wall18,wall19,wall20,wall21,wall22,wall23,wall24,wall25,wall26,wall27,wall28,wall29,wall30,wall31,wall32,wall33,wall34,wall35,wall36,wall37,wall38,wall39,wall40,wall41,wall42,wall43,wall44,wall45,wall46,wall47,wall48,wall49,wall50,wall51,wall52,wall53,wall54,wall55,wall56,wall57,wall58,wall59,wall60,wall61,wall62,wall63,wall64,wall65,wall66,wall67,wall68,wall69,wall70,wall71,wall72,wall73,wall74,wall75,wall76,wall77,wall78,wall79,wall80,wall81,wall82,wall83,wall84,wall85,wall86,wall87,wall88,wall89,wall90,wall91,wall92,wall93,wall94,wall95,wall96,wall97,wall98,wall99,wall100,wall101,wall102,wall103,wall104,wall105,wall106,wall107,wall108,wall109,wall110,wall111,wall112,wall113,wall114,wall115,wall116,wall117,wall118,wall119,wall120,wall121,wall122,wall123,wall124,wall125,wall126,wall127,wall128,wall129,wall130,wall131,wall132,wall133,wall134,wall135,wall136,wall137,wall138,wall139,wall140,wall141,wall142,wall143,wall144,wall145,wall146,wall147,wall148,wall149,wall150,wall151,wall152,wall153,wall154};
				//Move the dot
				dot.move(walls);
				dog1.move(walls);
				dog2.move(walls);
				dog3.move(walls);
				dog4.move(walls);
				dog5.move(walls);
				dog6.move(walls);
				dog7.move(walls);
				dog8.move(walls);
				
				//Center the camera over the dot
				camera.x = ( dot.getPosX() + Dot::DOT_WIDTH / 2 ) - SCREEN_WIDTH / 2;
				camera.y = ( dot.getPosY() + Dot::DOT_HEIGHT / 2 ) - SCREEN_HEIGHT / 2;

				//Keep the camera in bounds
				if( camera.x < 0 )
				{ 
					camera.x = 0;
				}
				if( camera.y < 0 )
				{
					camera.y = 0;
				}
				if( camera.x > LEVEL_WIDTH - camera.w )
				{
					camera.x = LEVEL_WIDTH - camera.w;
				}
				if( camera.y > LEVEL_HEIGHT - camera.h )
				{
					camera.y = LEVEL_HEIGHT - camera.h;
				}

				//Clear screen
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );
				SDL_RenderClear( gRenderer );

				
				
				//Render background
				gBGTexture.render( 0, 0, &camera );
				

				//Render objects
				dot.render( camera.x, camera.y );
				dog1.render( camera.x, camera.y );
				dog2.render( camera.x, camera.y );
				dog3.render( camera.x, camera.y );
				dog4.render( camera.x, camera.y );
				dog5.render( camera.x, camera.y );
				dog6.render( camera.x, camera.y );
				dog7.render( camera.x, camera.y );
				dog8.render( camera.x, camera.y );
				gscoreaTexture.render( 0,0 );
				gscorebTexture.render( 0,64 );
				switch (score%10){
					case 0:g0Texture.render( 192,0);break;
					case 1:g1Texture.render( 192,0);break;
					case 2:g2Texture.render( 192,0);break;
					case 3:g3Texture.render( 192,0);break;
					case 4:g4Texture.render( 192,0);break;
					case 5:g5Texture.render( 192,0);break;
					case 6:g6Texture.render( 192,0);break;
					case 7:g7Texture.render( 192,0);break;
					case 8:g8Texture.render( 192,0);break;
					case 9:g9Texture.render( 192,0);break;}
				switch ((score/10)%10){
					case 0:g0Texture.render( 128,0);break;
					case 1:g1Texture.render( 128,0);break;
					case 2:g2Texture.render( 128,0);break;
					case 3:g3Texture.render( 128,0);break;
					case 4:g4Texture.render( 128,0);break;
					case 5:g5Texture.render( 128,0);break;
					case 6:g6Texture.render( 128,0);break;
					case 7:g7Texture.render( 128,0);break;
					case 8:g8Texture.render( 128,0);break;
					case 9:g9Texture.render( 128,0);break;}
				switch ((score/100)%10){
					case 0:g0Texture.render( 64,0);break;
					case 1:g1Texture.render(64,0);break;
					case 2:g2Texture.render( 64,0);break;
					case 3:g3Texture.render(64,0);break;
					case 4:g4Texture.render( 64,0);break;
					case 5:g5Texture.render( 64,0);break;
					case 6:g6Texture.render(64,0);break;
					case 7:g7Texture.render( 64,0);break;
					case 8:g8Texture.render(64,0);break;
					case 9:g9Texture.render( 64,0);break;}
				
				if (j==1){
					i=rand()%23;
					j=0;}
				switch (i){
					case 0:gtask1Texture.render(640,0);break;
					case 1:gtask2Texture.render(640,0);break;
					case 2:gtask3Texture.render(640,0);break;
					case 3:gtask4Texture.render(640,0);break;
					case 4:gtask5Texture.render(640,0);break;
					case 5:gtask6Texture.render(640,0);break;
					case 6:gtask7Texture.render(640,0);break;
					case 7:gtask8Texture.render(640,0);break;
					case 8:gtask9Texture.render(640,0);break;
					case 9:gtask10Texture.render(640,0);break;
					case 10:gtask11Texture.render(640,0);break;
					case 11:gtask12Texture.render(640,0);break;
					case 12:gtask13Texture.render(640,0);break;
					case 13:gtask14Texture.render(640,0);break;
					case 14:gtask15Texture.render(640,0);break;
					case 15:gtask16Texture.render(640,0);break;
					case 16:gtask17Texture.render(640,0);break;
					case 17:gtask18Texture.render(640,0);break;
					case 18:gtask19Texture.render(640,0);break;
					case 19:gtask20Texture.render(640,0);break;
					case 20:gtask21Texture.render(640,0);break;
					case 21:gtask22Texture.render(640,0);break;
					case 22:gtask23Texture.render(640,0);break;}
					
					
				switch (i){
					case 0:if (dot.xxx==1){score=score+10;j=1;dot.xxx=0;}
					case 1:if (dot.xxx==2){score=score+10;j=1;dot.xxx=0;}
					case 2:if (dot.xxx==3){score=score+10;j=1;dot.xxx=0;}
					case 3:if (dot.xxx==4){score=score+10;j=1;dot.xxx=0;}
					case 4:if (dot.xxx==5){score=score+10;j=1;dot.xxx=0;}
					case 5:if (dot.xxx==6){score=score+10;j=1;dot.xxx=0;}
					case 6:if (dot.xxx==7){score=score+10;j=1;dot.xxx=0;}
					case 7:if (dot.xxx==8){score=score+10;j=1;dot.xxx=0;}
					case 8:if (dot.xxx==9){score=score+10;j=1;dot.xxx=0;}
					case 9:if (dot.xxx==10){score=score+10;j=1;dot.xxx=0;}
					case 10:if (dot.xxx==11){score=score+10;j=1;dot.xxx=0;}
					case 11:if (dot.xxx==12){score=score+10;j=1;dot.xxx=0;}					
					case 12:if (dot.xxx==13){score=score+10;j=1;dot.xxx=0;}
					case 13:if (dot.xxx==14){score=score+10;j=1;dot.xxx=0;}
					case 14:if (dot.xxx==15){score=score+10;j=1;dot.xxx=0;}
					case 15:if (dot.xxx==16){score=score+10;j=1;dot.xxx=0;}
					case 16:if (dot.xxx==17){score=score+10;j=1;dot.xxx=0;}
					case 17:if (dot.xxx==18){score=score+10;j=1;dot.xxx=0;}					
					case 18:if (dot.xxx==19){score=score+10;j=1;dot.xxx=0;}
					case 19:if (dot.xxx==20){score=score+10;j=1;dot.xxx=0;}
					case 20:if (dot.xxx==21){score=score+10;j=1;dot.xxx=0;}
					case 21:if (dot.xxx==22){score=score+10;j=1;dot.xxx=0;}
					case 22:if (dot.xxx==23){score=score+10;j=1;dot.xxx=0;}}
				
				//Update screen
				SDL_RenderPresent( gRenderer );
				
			}
		}
	}

	//Free resources and close SDL
	close();

	return 0;
}
